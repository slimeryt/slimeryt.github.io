import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function BlogPage() {
  const blogPosts = [
    {
      title: "Galaxy Executor v3.2 Update",
      description: "We've added new features and improved stability in our latest release.",
      date: "April 10, 2025",
      slug: "/blog/galaxy-executor-v3-2-update"
    },
    {
      title: "How to Use Script Hub Effectively",
      description: "Learn how to get the most out of Galaxy Executor's Script Hub feature.",
      date: "April 2, 2025",
      slug: "/blog/how-to-use-script-hub"
    },
    {
      title: "Top 10 Scripts for Beginners",
      description: "New to script execution? Here are the best scripts to start with.",
      date: "March 25, 2025",
      slug: "/blog/top-10-scripts-for-beginners"
    },
    {
      title: "Security Features in Galaxy Executor",
      description: "How we keep your experience secure while using our executor.",
      date: "March 18, 2025",
      slug: "/blog/security-features"
    },
  ];

  return (
    <main>
      <Header />
      <section className="py-16 md:py-24">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center">Latest Updates</h1>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-16">
            Stay up to date with the latest features, updates, and news about Galaxy Executor
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {blogPosts.map((post) => (
              <Card key={post.title} className="border bg-card text-card-foreground hover-card-effect">
                <CardHeader>
                  <CardTitle>{post.title}</CardTitle>
                  <CardDescription>{post.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{post.description}</p>
                </CardContent>
                <CardFooter>
                  <Link
                    href={post.slug}
                    className="text-primary hover:underline"
                  >
                    Read more →
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}

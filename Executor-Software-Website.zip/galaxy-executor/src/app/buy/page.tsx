import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { PricingSection } from "@/components/PricingSection";

export default function BuyPage() {
  return (
    <main>
      <Header />
      <section className="py-16 md:py-24">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center">Purchase Galaxy Executor</h1>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-16">
            Select a plan below and follow the instructions to complete your purchase with Robux
          </p>
        </div>
      </section>
      <PricingSection />
      <section className="py-16">
        <div className="container">
          <div className="max-w-3xl mx-auto bg-card rounded-lg p-8 border border-border/40">
            <h2 className="text-2xl font-bold mb-6">How to Purchase</h2>
            <ol className="space-y-4 list-decimal pl-5">
              <li className="text-foreground">
                <span className="font-semibold">Select a plan</span> - Choose the plan that fits your needs from the options above.
              </li>
              <li className="text-foreground">
                <span className="font-semibold">Click the "Buy" button</span> - You'll be directed to our Roblox game.
              </li>
              <li className="text-foreground">
                <span className="font-semibold">Join the game</span> - Follow the prompts to complete your purchase with Robux.
              </li>
              <li className="text-foreground">
                <span className="font-semibold">Download your executor</span> - After purchase, you'll receive a download link.
              </li>
              <li className="text-foreground">
                <span className="font-semibold">Enjoy!</span> - Install and start using Galaxy Executor.
              </li>
            </ol>

            <div className="mt-8 p-4 bg-primary/10 rounded-lg">
              <h3 className="font-semibold mb-2">Note:</h3>
              <p className="text-sm text-muted-foreground">
                All purchases are final. Make sure to read our terms of service before completing your purchase.
                If you encounter any issues during the payment process, please contact our support team.
              </p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}

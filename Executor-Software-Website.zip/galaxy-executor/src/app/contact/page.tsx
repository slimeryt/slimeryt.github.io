import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function ContactPage() {
  const contactMethods = [
    {
      title: "Discord",
      description: "Join our community Discord for support and updates",
      buttonText: "Join Discord",
      link: "/discord",
      icon: "🎮"
    },
    {
      title: "Email Support",
      description: "Email our support team for help with your purchase",
      buttonText: "Send Email",
      link: "mailto:support@galaxyexecutor.com",
      icon: "📧"
    },
  ];

  return (
    <main>
      <Header />
      <section className="py-16 md:py-24">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center">Contact Us</h1>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-16">
            Get in touch with our team for support, feedback, or questions about Galaxy Executor
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {contactMethods.map((method) => (
              <Card key={method.title} className="border bg-card text-card-foreground hover-card-effect">
                <CardHeader className="text-center pb-2">
                  <div className="text-4xl mb-4">{method.icon}</div>
                  <CardTitle>{method.title}</CardTitle>
                  <CardDescription className="mt-2">{method.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <Button asChild>
                    <Link href={method.link}>{method.buttonText}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-20 text-center">
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
              Check our <Link href="/faq" className="text-primary hover:underline">FAQ page</Link> for answers to common questions.
            </p>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}

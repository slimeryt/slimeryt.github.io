import { FeaturesSection } from "@/components/FeaturesSection";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { CallToAction } from "@/components/CallToAction";

export default function FeaturesPage() {
  return (
    <main>
      <Header />
      <section className="py-16 md:py-24">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center">Features</h1>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-16">
            Galaxy Executor comes packed with powerful features to enhance your gaming experience.
            Here's what makes it stand out from other executors.
          </p>
        </div>
      </section>
      <FeaturesSection />
      <CallToAction />
      <Footer />
    </main>
  );
}

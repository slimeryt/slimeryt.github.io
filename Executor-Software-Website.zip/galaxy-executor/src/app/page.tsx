import { CallToAction } from "@/components/CallToAction";
import { ExecutorShowcase } from "@/components/ExecutorShowcase";
import { FeaturesSection } from "@/components/FeaturesSection";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { PricingSection } from "@/components/PricingSection";
import { StatsSection } from "@/components/StatsSection";

export default function Home() {
  return (
    <main>
      <Header />
      <HeroSection />
      <StatsSection />
      <FeaturesSection />
      <ExecutorShowcase />
      <PricingSection />
      <CallToAction />
      <Footer />
    </main>
  );
}

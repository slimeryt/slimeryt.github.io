import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { PricingSection } from "@/components/PricingSection";
import { CallToAction } from "@/components/CallToAction";

export default function PricingPage() {
  return (
    <main>
      <Header />
      <section className="py-16 md:py-24">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center">Pricing</h1>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-16">
            Choose the pricing plan that fits your needs. All plans are paid with Robux and include access to Galaxy Executor.
          </p>
        </div>
      </section>
      <PricingSection />
      <section className="py-16">
        <div className="container">
          <div className="bg-card rounded-lg p-8 border border-border/40">
            <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">How do I pay with Robux?</h3>
                <p className="text-muted-foreground">
                  After selecting your plan, you'll be directed to a Roblox game where you can make the purchase using your Robux balance.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Can I upgrade my plan later?</h3>
                <p className="text-muted-foreground">
                  Yes! You can upgrade to a higher tier at any time. You'll only need to pay the difference in price.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Do you offer refunds?</h3>
                <p className="text-muted-foreground">
                  Due to the digital nature of our product, we cannot offer refunds once the purchase is complete.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <CallToAction />
      <Footer />
    </main>
  );
}

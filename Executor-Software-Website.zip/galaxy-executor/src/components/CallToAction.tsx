"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function CallToAction() {
  return (
    <section className="py-16 bg-accent/20">
      <div className="container text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Ready to elevate your gaming experience?
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          Join thousands of satisfied users and experience the power of Galaxy Executor today.
          No more limitations, no more waiting.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="rounded-lg" asChild>
            <Link href="/buy">Get Started Now</Link>
          </Button>
          <Button variant="outline" size="lg" className="rounded-lg" asChild>
            <Link href="/contact">Contact Support</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

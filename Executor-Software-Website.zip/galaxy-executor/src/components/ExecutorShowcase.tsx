"use client";

import { Card } from "@/components/ui/card";
import Image from "next/image";

export function ExecutorShowcase() {
  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Galaxy Executor in Action</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Powerful, sleek, and easy to use
          </p>
        </div>

        <Card className="overflow-hidden border-border/40 hover-card-effect rounded-lg">
          <div className="relative w-full h-[400px] md:h-[500px] bg-accent/10 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <p className="text-lg">Executor Preview</p>
              <p className="text-sm">(Placeholder for actual executor image)</p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}

"use client";

import { Card, CardContent } from "@/components/ui/card";

export function FeaturesSection() {
  const features = [
    {
      title: "Script Hub",
      description: "Access thousands of pre-made scripts for various games.",
      icon: "🌟",
    },
    {
      title: "Fast Execution",
      description: "Execute scripts instantly with no delay or lag.",
      icon: "⚡",
    },
    {
      title: "Stable Performance",
      description: "Our executor is optimized for stability and performance.",
      icon: "🛡️",
    },
    {
      title: "Regular Updates",
      description: "We constantly update to stay ahead of game patches.",
      icon: "🔄",
    },
    {
      title: "Easy to Use",
      description: "Simple and intuitive interface for beginners and pros.",
      icon: "👌",
    },
    {
      title: "24/7 Support",
      description: "Get help whenever you need it through our Discord.",
      icon: "🔧",
    },
  ];

  return (
    <section className="py-16 bg-accent/20">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Key Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Galaxy Executor offers a comprehensive set of features designed to enhance your gaming experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <Card key={feature.title} className="border bg-card text-card-foreground rounded-lg border-border/40 hover-card-effect">
              <CardContent className="p-6">
                <div className="text-3xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

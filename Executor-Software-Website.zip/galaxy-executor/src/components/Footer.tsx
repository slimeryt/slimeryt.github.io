"use client";

import Link from "next/link";

export function Footer() {
  return (
    <footer className="container mt-10 flex flex-wrap justify-between pb-16 pt-10 border-t">
      <div className="flex basis-full justify-between md:basis-auto md:flex-col md:justify-start gap-3.5">
        <Link className="flex items-center gap-3 font-bold text-xl" href="/">
          <span>G</span>
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-muted-foreground max-w-xs text-sm">
            © Copyright Galaxy Executor 2025
            <br />All Rights Reserved.
          </span>
        </div>
      </div>

      <div className="mt-10 flex basis-1/2 flex-col gap-5 md:mt-0 md:basis-auto text-sm">
        <h3 className="text-lg font-heading font-bold">Site</h3>
        <Link href="/features" className="text-muted-foreground hover:text-foreground transition-colors">
          Features
        </Link>
        <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
          Home
        </Link>
      </div>

      <div className="mt-10 flex basis-1/2 flex-col gap-5 md:mt-0 md:basis-auto text-sm">
        <h3 className="text-lg font-heading font-bold">Connect</h3>
        <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
          Contact Us
        </Link>
        <Link href="/discord" className="text-muted-foreground hover:text-foreground transition-colors">
          Discord
        </Link>
        <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
          FAQ
        </Link>
      </div>
    </footer>
  );
}

"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function HeroSection() {
  return (
    <section className="py-20 md:py-32 flex flex-col items-center justify-center text-center">
      <h1 className="text-4xl md:text-6xl font-bold mb-6">
        The ultimate script execution{" "}
        <span className="gradient-text">for everyone</span>
      </h1>
      <p className="text-lg text-muted-foreground max-w-2xl mb-10">
        We provide seamless script execution with unmatched stability and feature set.
        Our executor is trusted by thousands of users daily.
      </p>

      <div className="flex flex-col sm:flex-row gap-4 mt-4">
        <Button size="lg" className="rounded-lg" asChild>
          <Link href="/buy">Buy Now</Link>
        </Button>
        <Button variant="outline" size="lg" className="rounded-lg" asChild>
          <Link href="/features">View Features</Link>
        </Button>
      </div>
    </section>
  );
}

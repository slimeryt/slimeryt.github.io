"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export function PricingSection() {
  const plans = [
    {
      title: "Basic",
      description: "Perfect for beginners",
      price: "249 R$",
      features: [
        "Basic script execution",
        "Access to Script Hub",
        "Basic support",
        "1 month of updates"
      ],
      buttonText: "Buy Basic",
      popular: false,
      link: "/buy/basic"
    },
    {
      title: "Premium",
      description: "Most popular choice",
      price: "499 R$",
      features: [
        "Advanced script execution",
        "Full Script Hub access",
        "Priority support",
        "Lifetime updates",
        "Custom themes"
      ],
      buttonText: "Buy Premium",
      popular: true,
      link: "/buy/premium"
    },
    {
      title: "Pro",
      description: "For serious users",
      price: "999 R$",
      features: [
        "Ultimate script execution",
        "VIP Script Hub access",
        "24/7 Support",
        "Lifetime updates",
        "Custom themes",
        "Early access to new features"
      ],
      buttonText: "Buy Pro",
      popular: false,
      link: "/buy/pro"
    }
  ];

  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Choose Your Plan</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Select the plan that fits your needs and budget
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <Card
              key={plan.title}
              className={`border bg-card text-card-foreground rounded-lg hover-card-effect ${
                plan.popular ? "border-primary/50 shadow-md shadow-primary/10" : "border-border/40"
              }`}
            >
              <CardHeader>
                {plan.popular && (
                  <div className="py-1 px-3 bg-primary text-primary-foreground text-xs font-medium rounded-full w-fit mb-2">
                    Most Popular
                  </div>
                )}
                <CardTitle>{plan.title}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <p className="text-3xl font-bold">{plan.price}</p>
                <ul className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <span className="mr-2">✓</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant={plan.popular ? "default" : "outline"}
                  asChild
                >
                  <Link href={plan.link}>{plan.buttonText}</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

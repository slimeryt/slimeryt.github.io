"use client";

import { Card, CardContent } from "@/components/ui/card";

export function StatsSection() {
  const stats = [
    {
      title: "50K+",
      description: "Active Users",
      icon: "👥",
    },
    {
      title: "100M+",
      description: "Scripts Executed",
      icon: "📜",
    },
    {
      title: "99.9%",
      description: "Uptime Guarantee",
      icon: "⚡",
    },
  ];

  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Executor Stats</h2>
          <p className="text-muted-foreground">Our growth in numbers</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, index) => (
            <Card key={stat.title} className="border bg-card text-card-foreground rounded-lg border-border/40 hover-card-effect">
              <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                <div className="text-3xl mb-4">{stat.icon}</div>
                <h3 className="text-2xl md:text-4xl font-bold mb-2">{stat.title}</h3>
                <p className="text-muted-foreground">{stat.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
